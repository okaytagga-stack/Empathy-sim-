EMPATHYSIM + MINDTALK AI (NETLIFY)

ISI ZIP
- index.html: website EmpathySim, with MindTalk calling the Netlify function
- netlify/functions/mindtalk.mjs: backend that calls the OpenAI API securely
- netlify.toml: Netlify configuration

CARA DEPLOY DARI HP
1. Buka Netlify dan masuk ke situs/proyek EmpathySim kamu.
2. Cara paling aman untuk mengunggah folder dengan function adalah menghubungkan repository GitHub. Upload semua isi ZIP ini ke repository website (index.html harus di root), lalu di Netlify pilih Add new site / Import an existing project dan pilih repository itu. Jika situs sudah terhubung ke GitHub, ganti file website lama dengan index.html ini dan tambahkan folder netlify beserta netlify.toml, lalu commit/push.
3. Di Netlify: Site configuration (atau Project configuration) > Environment variables. Tambahkan OPENAI_API_KEY dengan API key milik OpenAI. Jangan tulis key di HTML atau kirim ke orang lain.
4. Deploy ulang setelah variabel ditambahkan.
5. Buka situs live, masuk ke MindTalk, lalu kirim pesan percobaan.

CATATAN PENTING
- API OpenAI biasanya ditagihkan terpisah dari langganan ChatGPT. Pastikan orang tua/wali membantu menyiapkan API account dan billing jika diperlukan.
- Backend memakai model gpt-4.1-mini secara default. Bisa diganti melalui environment variable OPENAI_MODEL.
- Untuk keamanan biaya, jangan bagikan URL/function atau API key ke publik dan pantau pemakaian API.
- Netlify drag-and-drop biasa untuk file statis tidak selalu menjalankan Functions; gunakan deploy berbasis Git repository atau CLI yang mendukung Functions.
