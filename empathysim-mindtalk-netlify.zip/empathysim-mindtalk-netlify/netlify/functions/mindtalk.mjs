const json = (statusCode, body) => ({ statusCode, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }, body: JSON.stringify(body) });

export async function handler(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, OPTIONS" }, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json(503, { error: "MindTalk is not configured yet. Add OPENAI_API_KEY in Netlify environment variables." });
  let payload;
  try { payload = JSON.parse(event.body || "{}"); } catch { return json(400, { error: "Invalid JSON" }); }
  const message = typeof payload.message === "string" ? payload.message.trim().slice(0, 5000) : "";
  const language = payload.language === "id" ? "Indonesian" : "English";
  if (!message) return json(400, { error: "Please enter a message." });
  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: `You are MindTalk, a warm, non-judgmental emotional reflection companion for a teen-focused empathy education website. Reply in ${language}. Acknowledge feelings, help the user reflect, and ask at most one gentle follow-up question. Do not diagnose, claim to be a therapist, or pressure the user to share. Keep replies concise and age-appropriate. Encourage reaching out to a trusted adult when a problem feels overwhelming or safety is involved. If the user may be in immediate danger, encourage them to contact local emergency help and a trusted adult now.`,
        input: message,
        max_output_tokens: 350
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("OpenAI API error", upstream.status, data?.error?.code || "unknown");
      return json(502, { error: "The AI service could not answer. Check API billing and key settings." });
    }
    const reply = (data.output || []).flatMap(item => item.content || []).filter(item => item.type === "output_text").map(item => item.text).join("\n").trim();
    if (!reply) return json(502, { error: "The AI returned an empty response. Please try again." });
    return json(200, { reply });
  } catch (error) {
    console.error("MindTalk backend error", error?.message || "unknown");
    return json(500, { error: "MindTalk had a temporary problem. Please try again." });
  }
}
